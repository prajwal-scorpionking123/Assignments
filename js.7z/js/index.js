var a=2

switch(a){
    default:
        console.log("good bye")
    case 1:
        console.log("one")
        break;
    case 2:
        console.log("two")
        
    case 3:
        console.log("three")
        break;
}